/* ===== جسر أندرويد لتطبيق الظهر: يُحقن في نسخة التطبيق فقط ===== */
(function () {
  if (!window.Android) return;

  /* ---------- 1) الحفظ والمشاركة عبر الجسر ---------- */
  function b64OfBytes(u8) {
    var s = '', CH = 0x8000;
    for (var i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
    return btoa(s);
  }
  async function toB64(data) {
    if (typeof data === 'string') return b64OfBytes(new TextEncoder().encode(data));
    var buf = await data.arrayBuffer();
    return b64OfBytes(new Uint8Array(buf));
  }
  function mimeOf(name, data) {
    if (data && data.type) return data.type;
    if (/\.json$/i.test(name)) return 'application/json';
    if (/\.png$/i.test(name)) return 'image/png';
    if (/\.(jpe?g)$/i.test(name)) return 'image/jpeg';
    if (/\.csv$/i.test(name)) return 'text/csv';
    return 'application/octet-stream';
  }

  /* الصفحة تستعمل claude.use('downloads').save({filename,data}) إن وُجد */
  window.claude = {
    use: async function (name) {
      if (name !== 'downloads') return null;
      return {
        save: async function (o) {
          var b64 = await toB64(o.data), mime = mimeOf(o.filename, o.data);
          if (/^image\//.test(mime)) {
            /* الصور: تُحفظ في الاستوديو */
            var r = Android.saveFile(b64, o.filename, mime);
            if (r !== 'ok') throw new Error('save failed');
          } else {
            /* الملفات: تفتح قائمة المشاركة (مدير الملفات، واتساب، جيميل...) */
            if (!Android.shareFile(b64, o.filename, mime)) throw new Error('share failed');
          }
          return true;
        }
      };
    }
  };

  /* المشاركة (واتساب وغيره) */
  navigator.canShare = function (d) { return !!(d && d.files && d.files.length); };
  navigator.share = async function (d) {
    var f = d && d.files && d.files[0];
    if (!f) throw new Error('nothing to share');
    var b64 = await toB64(f);
    if (!Android.shareFile(b64, f.name, f.type || mimeOf(f.name))) throw new Error('share failed');
  };

  /* حفظ ملف: قائمة المشاركة (مدير الملفات وغيره) */
  window.__saveAsFile = async function (data, name, mime) {
    try {
      var b64 = await toB64(data);
      return !!Android.shareFile(b64, name, mime || mimeOf(name, data));
    } catch (e) { return false; }
  };

  /* ---------- 2) مزامنة التنبيهات (الأذان + عزوة) إلى المنبّه الأصلي ---------- */
  var DAYS = 14, lastJson = '', timer = null, sent = {};

  function b64Of(src) { var i = String(src || '').indexOf(','); return i < 0 ? '' : src.slice(i + 1); }
  function sendTone(key, src) {
    var sig = key + ':' + String(src).length;
    if (sent[sig]) return true;
    var b = b64Of(src);
    if (!b) return false;
    if (Android.storeTone(key, b)) { sent[sig] = 1; return true; }
    return false;
  }

  function adhanItems(out) {
    if (!window.__agAdhanList) return;
    var tone = '';
    try { var src = window.__agAdhanSrc && window.__agAdhanSrc(); if (!src && window.__ADH) src = window.__ADH.f1; if (src && sendTone('c_adhan', src)) tone = 'c_adhan'; } catch (e) { }
    window.__agAdhanList(7).forEach(function (x) {
      out.push({ id: 'ad|' + x.at, at: x.at, title: 'أذان ' + x.name, body: 'حان الآن وقت صلاة ' + x.name, meta: { tone: tone || 'bell', say: 'حان وقت صلاة ' + x.name } });
    });
  }

  function azToneFor(w, a) {
    var s = a.sound || 'chime';
    try {
      if (/^u:/.test(s)) {
        var d = w.uSnd(s);
        var key = 'c_az_' + String(a.id).replace(/[^A-Za-z0-9]/g, '');
        if (d && d.data && sendTone(key, d.data)) return key;
        return 'chime';
      }
    } catch (e) { }
    return /^[a-z0-9]+$/.test(s) ? s : 'chime';
  }

  function azItems(out) {
    var fr = window.azFrame && window.azFrame(), w = fr && fr.contentWindow;
    if (!w || !w.eval || !w.nextOcc) return;
    var S = w.eval('S'), now = Date.now() + 2000, lim = now + DAYS * 864e5;
    (S.alarms || []).forEach(function (a) {
      if (!a.enabled) return;
      var t = null, n = 0, ttl = '';
      try { ttl = w.title(a); t = w.nextOcc(a, now); } catch (e) { return; }
      var tone = azToneFor(w, a), body = '';
      try { body = a.type === 'time' ? 'منبه عزوة' : w.descA(a); } catch (e) { }
      while (t && t < lim && n < 40) {
        out.push({ id: 'az|' + a.id + '|' + t, at: t, title: ttl, body: body, meta: { tone: tone, say: ttl } });
        if (!a.repeat || a._at) break;
        try { t = w.nextOcc(a, t + 1000); } catch (e) { break; }
        n++;
      }
    });
    (S.timers || []).forEach(function (m) {
      if (m.end && m.end > now && !m.done) out.push({ id: 'tm|' + m.id, at: m.end, title: 'انتهى منبه الطعام', body: 'مضى الوقت المحدد', meta: { tone: 'chime', say: 'انتهى منبه الطعام' } });
    });
  }

  function buildList() {
    var out = [];
    try { adhanItems(out); } catch (e) { }
    try { azItems(out); } catch (e) { }
    out.sort(function (x, y) { return x.at - y.at; });
    return out.slice(0, 400);
  }

  window.nativeSyncNow = function () {
    try {
      var list = buildList(), json = JSON.stringify(list);
      if (json === lastJson && Android.alarmCount() === list.length) return;
      Android.setAlarms(json);
      lastJson = json;
    } catch (e) { }
  };
  window.nativeSyncSoon = function () { clearTimeout(timer); timer = setTimeout(window.nativeSyncNow, 1200); };

  addEventListener('load', function () { setTimeout(window.nativeSyncNow, 4000); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) window.nativeSyncNow(); else window.nativeSyncSoon(); });
  setInterval(function () { if (!document.hidden) window.nativeSyncNow(); }, 20000);

  /* ---------- 3) أزرار الاختبار والأذونات في بطاقة صوت الأذان ---------- */
  function addButtons() {
    var sel = document.getElementById('sAd');
    if (!sel || document.getElementById('nvTest')) return;
    var card = sel.closest('.ag-sc') || sel.parentNode;
    var box = document.createElement('div');
    box.className = 'ag-snd';
    box.style.marginTop = '10px';
    box.innerHTML = '<button type="button" class="ag-sbtn ag-pri ag-mini" id="nvTest">🔔 تجربة منبه حقيقي (١٠ ثوانٍ)</button><button type="button" class="ag-sbtn ag-mini" id="nvPerm">🔓 الأذونات</button>';
    card.appendChild(box);
    document.getElementById('nvTest').onclick = function () {
      window.nativeSyncNow();
      Android.setAlarmMeta('test|' + Date.now(), Date.now() + 10000, 'تجربة منبه', 'هذا اختبار الصوت والشاشة', JSON.stringify({ tone: 'ip3', say: 'تجربة منبه' }));
      var m = document.getElementById('sAdM'); if (m) m.textContent = 'سيرن بعد ١٠ ثوانٍ، أطفئ الشاشة لتجرّبه.';
    };
    document.getElementById('nvPerm').onclick = function () { Android.requestPermissions(); };
  }
  addEventListener('load', function () { setTimeout(addButtons, 1500); });
})();
